# Trefferstatistik – GitHub Pages

Dateien:
- index.html
- style.css
- app.js

## Veröffentlichung

1. Neues GitHub-Repository erstellen.
2. Alle drei Dateien in das Hauptverzeichnis hochladen.
3. Settings → Pages.
4. Source: Deploy from a branch.
5. Branch: main.
6. Folder: / (root).
7. Speichern.

Adresse:
https://DEIN-BENUTZERNAME.github.io/REPOSITORY-NAME/

## Hinweis
Die Dateien sind bereits sauber getrennt. `index.html` lädt `style.css` und `app.js`.
