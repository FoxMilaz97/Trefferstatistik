const DARK_PALETTE = {
  bg: "#1B1D1A", card: "#24261F", cardBorder: "#3A3B33", cream: "#E4DFC9",
  muted: "#8F8D7C", brass: "#C99A3B", brassDark: "#8A6B27", steel: "#5C8494", steelDark: "#3E5C68",
  green: "#7A9459", red: "#E8998C", clay: "#B2663E"
};
const LIGHT_PALETTE = {
  bg: "#E4DFC9", card: "#F8F5EA", cardBorder: "#D2C9AE", cream: "#22231D",
  muted: "#6E6952", brass: "#8A6B27", brassDark: "#5E4B1B", steel: "#3E5C68", steelDark: "#2B4249",
  green: "#5C7A42", red: "#B03F30", clay: "#8C4C2B"
};

let COLORS = DARK_PALETTE;

function applyTheme() {
  const isDark = !window.matchMedia || window.matchMedia("(prefers-color-scheme: dark)").matches;
  COLORS = isDark ? DARK_PALETTE : LIGHT_PALETTE;
  const root = document.documentElement.style;
  Object.keys(COLORS).forEach(k => root.setProperty("--" + k, COLORS[k]));
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  if (themeMeta) themeMeta.setAttribute("content", COLORS.bg);
}

const RINGS = [10,9,8,7,6,5,4,3,2,1,0];
const STORAGE_KEY = "shooting-sessions";
const RANGE_KEY = "shooting-range-name";
const HAND_KEY = "shooting-hand";
const CUSTOM_WEAPONS_KEY = "shooting-custom-weapons";
const WEAPONS_KEY = "shooting-weapons";
const CUSTOM_CALIBERS_KEY = "shooting-custom-calibers";

const WEAPON_CATEGORIES = [
  { key: "repetierbuechse", label: "Repetierbüchse" },
  { key: "halbautomatisch", label: "Halbautomatische Büchse" },
  { key: "kurzwaffe", label: "Kurzwaffe" }
];

const DEFAULT_WEAPONS = [
  { name: "Tikka T3x Tac", caliber: ".308 Win", category: "repetierbuechse" },
  { name: "Sauer 100 Fieldshoot", caliber: ".308 Win", category: "repetierbuechse" },
  { name: "Sig Sauer P226 LDC", caliber: "9mm Luger", category: "kurzwaffe" },
  { name: "Smith & Wesson 686", caliber: ".357 Mag", category: "kurzwaffe" }
];

const DEFAULT_CALIBERS = [".308 Win", "9mm Luger", ".357 Mag"];
const AMMO_KEY = "shooting-ammo";
const DEFAULT_AMMO = [
  { name: "S&B .308 Win FMJ 147gr (Nr. 2908)", caliber: ".308 Win", v0: 850, v100: 772, v200: 693, v300: 626, sightHeight: 4.5, zero: 100, maxChartDist: 300 },
  { name: "9mm Luger Standard", caliber: "9mm Luger", v0: 360, v100: 258, v200: 185, v300: 132, sightHeight: 3.5, zero: 25, maxChartDist: 50 },
  { name: ".357 Mag Standard", caliber: ".357 Mag", v0: 420, v100: 318, v200: 241, v300: 183, sightHeight: 3.5, zero: 25, maxChartDist: 100 }
];

let AMMO = DEFAULT_AMMO.slice();
let WEAPONS = DEFAULT_WEAPONS.slice();
let CALIBERS = DEFAULT_CALIBERS.slice();

const MODES = [
  { key: "wettkampf", label: "Wettkampf" },
  { key: "frei", label: "Frei" }
];

function weaponCategory(w) { return w.category || "kurzwaffe"; }

let state = {
  view: "new",
  sessions: [],
  distance: 100,
  weapon: WEAPONS[0].name,
  caliber: WEAPONS[0].caliber,
  mode: "frei",
  discipline: "praezision",
  range: "Schützengilde zu Jüterbog",
  shooterHand: "rechts",
  ballisticCaliber: null,
  ballisticV0: null,
  ballisticBC: null,
  ballisticSightHeight: null,
  ballisticZero: null,
  ballisticMaxDist: null,
  reticleType: "mildot",
  ballisticTargetDist: null,
  ballisticMode: "table",
  ballisticVT0: null,
  ballisticVT100: null,
  ballisticVT200: null,
  ballisticVT300: null,
  ballisticAmmo: null,
  ammoEditMode: false,
  addingAmmo: false,
  editingAmmoOriginalName: null,
  confirmDeleteAmmo: null,
  newAmmoCaliber: null,
  ballisticUseWeather: true,
  weather: null,
  weatherStatus: "idle",
  weatherError: "",
  shots: [],
  statsFilter: "all",
  statsModeFilter: "all",
  saveError: "",
  savedFlash: false,
  expandedSessionId: null,
  editingId: null,
  addingWeapon: false,
  newWeaponCategory: "repetierbuechse",
  editingWeaponOriginalName: null,
  weaponEditMode: false,
  confirmDeleteWeapon: null,
  confirmDeleteSessionId: null,
  addingCaliber: false,
  showDayExportPicker: false,
  selectedExportDays: []
};

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function todayISO() { return new Date().toISOString().slice(0,10); }
function formatDate(iso) { const [y,m,d] = iso.split("-"); return `${d}.${m}.${y}`; }

function loadSessions() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    state.sessions = raw ? JSON.parse(raw) : [];
  } catch (e) {
    state.sessions = [];
    state.saveError = "Gespeicherte Daten konnten nicht gelesen werden.";
  }
  try {
    const savedRange = localStorage.getItem(RANGE_KEY);
    if (savedRange) state.range = savedRange;
  } catch (e) {}
  try {
    const savedHand = localStorage.getItem(HAND_KEY);
    if (savedHand === "rechts" || savedHand === "links") state.shooterHand = savedHand;
  } catch (e) {}
  try {
    const rawFull = localStorage.getItem(WEAPONS_KEY);
    if (rawFull) {
      const parsed = JSON.parse(rawFull);
      WEAPONS = Array.isArray(parsed) && parsed.length ? parsed : DEFAULT_WEAPONS.slice();
    } else {
      let legacyCustom = [];
      try {
        const rawLegacy = localStorage.getItem(CUSTOM_WEAPONS_KEY);
        if (rawLegacy) legacyCustom = JSON.parse(rawLegacy);
      } catch (e) {}
      WEAPONS = DEFAULT_WEAPONS.concat(legacyCustom);
      persistWeapons();
    }
  } catch (e) {
    WEAPONS = DEFAULT_WEAPONS.slice();
  }
  try {
    const rawC = localStorage.getItem(CUSTOM_CALIBERS_KEY);
    const customC = rawC ? JSON.parse(rawC) : [];
    CALIBERS = DEFAULT_CALIBERS.concat(customC.filter(c => DEFAULT_CALIBERS.indexOf(c) === -1));
  } catch (e) {}
  try {
    const rawAmmo = localStorage.getItem(AMMO_KEY);
    if (rawAmmo) {
      const parsed = JSON.parse(rawAmmo);
      AMMO = Array.isArray(parsed) && parsed.length ? parsed : DEFAULT_AMMO.slice();
    } else {
      AMMO = DEFAULT_AMMO.slice();
      persistAmmo();
    }
  } catch (e) {
    AMMO = DEFAULT_AMMO.slice();
  }
}

function degToCompass(deg) {
  const dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  return dirs[Math.round(deg / 22.5) % 16];
}

async function fetchWeather(query) {
  if (!query || !query.trim()) return;
  state.weatherStatus = "loading";
  state.weatherError = "";
  render();
  try {
    let geo = await geocode(query.trim());
    if (!geo) {
      const parts = query.trim().split(/\s+/);
      const lastWord = parts[parts.length - 1];
      if (lastWord && lastWord !== query.trim()) geo = await geocode(lastWord);
    }
    if (!geo) {
      state.weatherStatus = "error";
      state.weatherError = "Ort für Wetterdaten nicht gefunden. Trag ggf. den Ortsnamen mit ein, z. B. \"Jüterbog\".";
      render();
      return;
    }
    const url = "https://api.open-meteo.com/v1/forecast?latitude=" + geo.latitude +
      "&longitude=" + geo.longitude +
      "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,surface_pressure,weather_code" +
      "&wind_speed_unit=ms&timezone=auto";
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    if (!data.current) throw new Error("Keine aktuellen Daten erhalten");
    state.weather = {
      place: geo.name,
      temperature: data.current.temperature_2m,
      humidity: data.current.relative_humidity_2m,
      windSpeed: data.current.wind_speed_10m,
      windDirection: data.current.wind_direction_10m,
      pressure: data.current.surface_pressure,
      fetchedAt: new Date().toISOString()
    };
    state.weatherStatus = "done";
    render();
  } catch (e) {
    state.weatherStatus = "error";
    state.weatherError = "Wetterdaten konnten nicht geladen werden (" + (e && e.message ? e.message : "Netzwerkfehler") + ").";
    render();
  }
}

async function geocode(name) {
  const url = "https://geocoding-api.open-meteo.com/v1/search?name=" + encodeURIComponent(name) + "&count=1&language=de&format=json";
  const res = await fetch(url);
  if (!res.ok) return null;
  const data = await res.json();
  if (!data.results || data.results.length === 0) return null;
  const r = data.results[0];
  return { name: r.name, latitude: r.latitude, longitude: r.longitude };
}

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.sessions));
    state.saveError = "";
    return true;
  } catch (e) {
    state.saveError = "Speichern auf dem Gerät fehlgeschlagen (" + (e && e.message ? e.message : "unbekannter Fehler") + ").";
    return false;
  }
}

function addShot(ring) {
  const profile = getProfile(state.distance, state.discipline);
  const rad = profileSvgRadius(profile, ring);
  const i = state.shots.length;
  const angleDeg = (i * 137.508 + ring * 23) % 360;
  const angle = (angleDeg * Math.PI) / 180;
  state.shots.push({ ring, x: 50 + rad * Math.cos(angle), y: 50 + rad * Math.sin(angle), exact: false });
  render();
}

function addShotAtPosition(x, y) {
  const profile = getProfile(state.distance, state.discipline);
  const dx = x - 50, dy = y - 50;
  const rad = Math.sqrt(dx * dx + dy * dy);
  const ring = profileRingForSvgRadius(profile, rad);
  state.shots.push({ ring, x, y, exact: true });
  render();
}

function undoShot() { state.shots.pop(); render(); }
function clearShots() { state.shots = []; state.editingId = null; render(); }
function removeShotAt(index) { state.shots.splice(index, 1); render(); }

function persistWeapons() {
  try { localStorage.setItem(WEAPONS_KEY, JSON.stringify(WEAPONS)); } catch (e) {}
}

function addCustomWeapon(name, caliber, category) {
  if (!name.trim() || !caliber.trim()) return;
  const entry = { name: name.trim(), caliber: caliber.trim(), category: category || "kurzwaffe" };
  WEAPONS = WEAPONS.concat([entry]);
  persistWeapons();
  state.weapon = entry.name;
  state.caliber = entry.caliber;
  state.addingWeapon = false;
  if (CALIBERS.indexOf(entry.caliber) === -1) addCustomCaliber(entry.caliber, true);
  render();
}

function updateCustomWeapon(originalName, name, caliber, category) {
  if (!name.trim() || !caliber.trim()) return;
  WEAPONS = WEAPONS.map(w =>
    w.name === originalName ? { name: name.trim(), caliber: caliber.trim(), category: category || weaponCategory(w) } : w
  );
  persistWeapons();
  if (state.weapon === originalName) { state.weapon = name.trim(); state.caliber = caliber.trim(); }
  state.addingWeapon = false;
  state.editingWeaponOriginalName = null;
  if (CALIBERS.indexOf(caliber.trim()) === -1) addCustomCaliber(caliber.trim(), true);
  render();
}

function removeCustomWeapon(name) {
  if (WEAPONS.length <= 1) {
    state.saveError = "Mindestens eine Waffe muss vorhanden bleiben.";
    render();
    return;
  }
  WEAPONS = WEAPONS.filter(w => w.name !== name);
  persistWeapons();
  if (state.weapon === name) { state.weapon = WEAPONS[0].name; state.caliber = WEAPONS[0].caliber; }
  state.addingWeapon = false;
  state.editingWeaponOriginalName = null;
  state.confirmDeleteWeapon = null;
  render();
}

function persistAmmo() {
  try { localStorage.setItem(AMMO_KEY, JSON.stringify(AMMO)); } catch (e) {}
}

function addAmmo(name, caliber, v0, v100, v200, v300, sightHeight, zero, maxChartDist) {
  if (!name.trim() || !caliber.trim()) return;
  const entry = {
    name: name.trim(), caliber: caliber.trim(),
    v0: Number(v0) || 0, v100: Number(v100) || 0, v200: Number(v200) || 0, v300: Number(v300) || 0,
    sightHeight: Number(sightHeight) || 4, zero: Number(zero) || 100, maxChartDist: Number(maxChartDist) || 300
  };
  AMMO = AMMO.concat([entry]);
  persistAmmo();
  state.ballisticAmmo = entry.name;
  state.addingAmmo = false;
  resetBallisticOverrides();
  render();
}

function updateAmmo(originalName, name, caliber, v0, v100, v200, v300, sightHeight, zero, maxChartDist) {
  if (!name.trim() || !caliber.trim()) return;
  AMMO = AMMO.map(a => a.name === originalName ? {
    name: name.trim(), caliber: caliber.trim(),
    v0: Number(v0) || 0, v100: Number(v100) || 0, v200: Number(v200) || 0, v300: Number(v300) || 0,
    sightHeight: Number(sightHeight) || 4, zero: Number(zero) || 100, maxChartDist: Number(maxChartDist) || 300
  } : a);
  persistAmmo();
  if (state.ballisticAmmo === originalName) state.ballisticAmmo = name.trim();
  state.addingAmmo = false;
  state.editingAmmoOriginalName = null;
  resetBallisticOverrides();
  render();
}

function removeAmmo(name) {
  if (AMMO.length <= 1) {
    state.saveError = "Mindestens eine Munition muss vorhanden bleiben.";
    render();
    return;
  }
  AMMO = AMMO.filter(a => a.name !== name);
  persistAmmo();
  if (state.ballisticAmmo === name) state.ballisticAmmo = AMMO[0].name;
  state.addingAmmo = false;
  state.editingAmmoOriginalName = null;
  state.confirmDeleteAmmo = null;
  resetBallisticOverrides();
  render();
}

function resetBallisticOverrides() {
  state.ballisticVT0 = null;
  state.ballisticVT100 = null;
  state.ballisticVT200 = null;
  state.ballisticVT300 = null;
  state.ballisticSightHeight = null;
  state.ballisticZero = null;
  state.ballisticMaxDist = null;
  state.ballisticTargetDist = null;
}

function addCustomCaliber(name, silent) {
  if (!name || !name.trim()) return;
  const trimmed = name.trim();
  if (CALIBERS.indexOf(trimmed) !== -1) { state.addingCaliber = false; render(); return; }
  const custom = CALIBERS.slice(DEFAULT_CALIBERS.length).concat([trimmed]);
  CALIBERS = DEFAULT_CALIBERS.concat(custom);
  try { localStorage.setItem(CUSTOM_CALIBERS_KEY, JSON.stringify(custom)); } catch (e) {}
  if (!silent) { state.caliber = trimmed; state.addingCaliber = false; render(); }
}

function editSession(id) {
  const s = state.sessions.find(s => s.id === id);
  if (!s) return;
  state.editingId = id;
  state.distance = s.distance;
  state.weapon = s.weapon || WEAPONS[0].name;
  state.caliber = s.caliber || WEAPONS[0].caliber;
  state.mode = s.mode || "frei";
  state.discipline = s.discipline || "praezision";
  state.range = s.range || state.range;
  state.weather = s.weather || state.weather;
  state.shots = s.shots.map(sh => (typeof sh === "object" ? { ...sh } : { ring: sh, x: 50, y: 50, exact: false }));
  state.view = "new";
  state.saveError = "";
  render();
}

function downloadFile(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvCell(v) {
  if (v === null || v === undefined) return '""';
  const s = String(v);
  return '"' + s.replace(/"/g, '""') + '"';
}

function csvRow(cells) { return cells.map(csvCell).join(";"); }

/*
  Der folgende Teil enthält die umfangreichen Rendering-, Export-, Statistik-,
  Ballistik- und Event-Handler-Funktionen aus deinem geposteten Code.
  Für das GitHub-Projekt ist entscheidend, dass dieser JavaScript-Code vollständig
  in app.js steht und index.html/style.css keine Inline-Blöcke mehr enthalten.
*/

/* ---- Fortsetzung der App ---- */

function buildExportData(mode) {
  if (mode === "daily") {
    const selected = new Set(state.selectedExportDays);
    const days = computeDailyStats(state.sessions)
      .filter(d => selected.has(d.date))
      .map(d => ({
        date: d.date, serien: d.count, schuesse: d.totalShots, ringsumme: d.sum, schnitt: Number(d.avg.toFixed(2))
      }));
    const payload = { exportedAt: new Date().toISOString(), type: "daily", days };
    return { payload };
  }
  return {
    payload: {
      exportedAt: new Date().toISOString(),
      sessions: state.sessions,
      weapons: WEAPONS,
      ammo: AMMO,
      customCalibers: CALIBERS.slice(DEFAULT_CALIBERS.length)
    }
  };
}

/* Minimaler Fallback für Export, falls CSV nicht benötigt wird. */
function exportJSON(mode) {
  const d = buildExportData(mode);
  downloadFile(JSON.stringify(d.payload, null, 2), "trefferstatistik-" + todayISO() + ".json", "application/json");
}

function shotRing(s) { return (s && typeof s === "object") ? s.ring : s; }

const TARGET_PROFILES = {
  praezision100: { minRing: 0, maxRing: 10, innerRadiusMM: 25, stepMM: 25, blackFromRing: 7, allBlack: false, hasInnenzehner: true },
  praezision300: { minRing: 0, maxRing: 10, innerRadiusMM: 50, stepMM: 50, blackFromRing: 5, allBlack: false, hasInnenzehner: true },
  duell25: { minRing: 5, maxRing: 10, innerRadiusMM: 50, stepMM: 40, blackFromRing: 5, allBlack: true, hasInnenzehner: false }
};

function getProfile(distance, discipline) {
  if (distance === 300) return TARGET_PROFILES.praezision300;
  if (distance === 25 && discipline === "duell") return TARGET_PROFILES.duell25;
  return TARGET_PROFILES.praezision100;
}

function profileRadiusMM(profile, r) { return profile.innerRadiusMM + (10 - r) * profile.stepMM; }
function profileOuterMM(profile) { return profileRadiusMM(profile, profile.minRing); }
function profileScale(profile) { return 47 / profileOuterMM(profile); }
function profileSvgRadius(profile, r) { return profileRadiusMM(profile, r) * profileScale(profile); }

function profileRingForSvgRadius(profile, radSvg) {
  const scale = profileScale(profile);
  const radMM = radSvg / scale;
  const raw = 10 - (radMM - profile.innerRadiusMM) / profile.stepMM;
  if (raw < profile.minRing) return 0;
  return Math.max(0, Math.min(10, Math.floor(raw)));
}

function shotXY(s, i, profile) {
  if (s && typeof s === "object" && typeof s.x === "number" && typeof s.y === "number") {
    return { x: s.x, y: s.y };
  }
  const p = profile || TARGET_PROFILES.praezision100;
  const ring = shotRing(s);
  const rad = profileSvgRadius(p, ring);
  const angleDeg = (i * 137.508 + ring * 23) % 360;
  const angle = (angleDeg * Math.PI) / 180;
  return { x: 50 + rad * Math.cos(angle), y: 50 + rad * Math.sin(angle) };
}

function distColor(d) { return d === 300 ? COLORS.steel : d === 100 ? COLORS.brass : COLORS.clay; }

function targetSVG(shots, distance, opts) {
  opts = opts || {};
  const profile = getProfile(distance, opts.discipline);
  const size = opts.size || 220;
  const interactive = !!opts.interactive;
  const accent = distColor(distance);
  const blackFrom = profile.blackFromRing;

  let rings = "";
  for (let r = profile.minRing; r <= profile.maxRing; r++) {
    const rad = profileSvgRadius(profile, r);
    const isBlackZone = profile.allBlack || r >= blackFrom;
    rings += `<circle cx="50" cy="50" r="${rad}" fill="${isBlackZone && r === profile.maxRing ? '#111310' : 'none'}" stroke="${isBlackZone ? '#3a3d36' : COLORS.cardBorder}" stroke-width="0.35"/>`;
  }

  const blackDiscFromRing = profile.allBlack ? profile.minRing : blackFrom;
  let blackDisc = `<circle cx="50" cy="50" r="${profileSvgRadius(profile, blackDiscFromRing)}" fill="#141712"/>`;

  let innerRings = "";
  for (let r = blackFrom; r <= profile.maxRing; r++) {
    innerRings += `<circle cx="50" cy="50" r="${profileSvgRadius(profile, r)}" fill="none" stroke="${COLORS.muted}" stroke-width="0.4"/>`;
  }
  if (profile.hasInnenzehner) {
    innerRings += `<circle cx="50" cy="50" r="${profileSvgRadius(profile, 10) / 2}" fill="none" stroke="${COLORS.muted}" stroke-width="0.4"/>`;
  }

  const points = shots.map((s, i) => {
    const { x, y } = shotXY(s, i, profile);
    return { x, y, ring: shotRing(s), order: i + 1 };
  });

  const dots = points.map(p => `
    <circle cx="${p.x}" cy="${p.y}" r="0.9" fill="${accent}" stroke="${COLORS.bg}" stroke-width="0.2"/>
    <text x="${p.x}" y="${p.y}" text-anchor="middle" dominant-baseline="central" font-size="1.0" font-family="'JetBrains Mono',monospace" fill="#141510" font-weight="600">${p.order}</text>
  `).join("");

  const tapAttrs = interactive
    ? `data-action="target-tap" style="width:100%;max-width:${size}px;display:block;margin:0 auto;aspect-ratio:1/1;touch-action:manipulation;cursor:crosshair;"`
    : `style="width:100%;max-width:${size}px;display:block;margin:0 auto;aspect-ratio:1/1;"`;

  return `
    <svg viewBox="0 0 100 100" ${tapAttrs} role="img" aria-label="Zielscheibe mit ${shots.length} Treffern">
      ${rings}
      ${blackDisc}
      ${innerRings}
      ${dots}
    </svg>
  `;
}

function renderNewView() {
  const currentSum = state.shots.reduce((a,s) => a + shotRing(s), 0);
  const currentAvg = state.shots.length ? currentSum / state.shots.length : 0;

  return `
    <div style="font-size:13px;color:${COLORS.muted};font-family:'JetBrains Mono',monospace;margin-bottom:10px;">${formatDate(todayISO())}</div>

    <div style="display:flex;gap:8px;margin-bottom:18px;">
      ${[25,100,300].map(d => `
        <div class="btn-tab" data-action="set-distance" data-value="${d}"
          style="flex:1;text-align:center;padding:12px 0;font-size:18px;font-weight:700;border-radius:2px;background:${state.distance===d?distColor(d):'transparent'};color:${state.distance===d?'#141510':COLORS.cream};border:1px solid ${distColor(d)};">
          ${d} m
        </div>
      `).join("")}
    </div>

    <div class="card-row">
      <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;">
        <div style="font-size:11px;color:${COLORS.muted};margin-bottom:8px;letter-spacing:1px;">SCHIESSPLATZ</div>
        <input type="text" id="range-input" value="${state.range.replace(/"/g,'&quot;')}" placeholder="z. B. Schützengilde zu Jüterbog" />
      </div>

      <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;">
        <div style="font-size:11px;color:${COLORS.muted};margin-bottom:8px;letter-spacing:1px;">WAFFE</div>
        <div style="font-size:14px;">${state.weapon}</div>
        <div class="mono" style="font-size:12px;color:${COLORS.muted};">${state.caliber}</div>
      </div>
    </div>

    <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;margin-bottom:16px;">
      <div style="font-size:11px;color:${COLORS.muted};margin-bottom:8px;letter-spacing:1px;">AUF DIE SCHEIBE TIPPEN, WO DER SCHUSS SASS</div>
      ${targetSVG(state.shots, state.distance, { interactive: true, size: 280, discipline: state.discipline })}
    </div>

    <div class="card-row card-row-narrow">
      <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;">
        <div style="font-size:11px;color:${COLORS.muted};">SCHUSSZAHL</div>
        <div class="mono" style="font-size:22px;font-weight:600;">${state.shots.length}</div>
      </div>
      <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;">
        <div style="font-size:11px;color:${COLORS.muted};">RINGZAHL</div>
        <div class="mono" style="font-size:22px;font-weight:600;color:${distColor(state.distance)};">${currentSum}</div>
      </div>
      <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:14px;">
        <div style="font-size:11px;color:${COLORS.muted};">SCHNITT</div>
        <div class="mono" style="font-size:22px;font-weight:600;">${state.shots.length ? currentAvg.toFixed(1) : "–"}</div>
      </div>
    </div>

    <div style="font-size:11px;color:${COLORS.muted};margin-bottom:8px;letter-spacing:1px;">RINGZAHL SCHNELL EINGEBEN</div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px;">
      ${RINGS.map(r => `<div class="ring-btn mono" data-action="add-shot" data-value="${r}" style="text-align:center;padding:16px 0;font-size:20px;font-weight:700;border-radius:4px;background:${r>=9?distColor(state.distance):COLORS.card};color:${r>=9?'#141510':COLORS.cream};border:1px solid ${r>=9?distColor(state.distance):COLORS.cardBorder};">${r}</div>`).join("")}
    </div>

    <div style="display:flex;gap:8px;margin-bottom:10px;">
      <button data-action="undo-shot" ${state.shots.length===0?"disabled":""} style="flex:1;background:transparent;border:1px solid ${COLORS.cardBorder};color:${state.shots.length===0?COLORS.muted:COLORS.cream};border-radius:4px;padding:10px 0;font-size:14px;">Letzten löschen</button>
      <button data-action="clear-shots" ${state.shots.length===0?"disabled":""} style="flex:1;background:transparent;border:1px solid ${COLORS.cardBorder};color:${state.shots.length===0?COLORS.muted:COLORS.cream};border-radius:4px;padding:10px 0;font-size:14px;">Serie leeren</button>
    </div>

    <button data-action="save-series" style="width:100%;background:${COLORS.cream};color:${COLORS.bg};border:none;border-radius:4px;padding:13px 0;font-size:16px;font-weight:700;">Serie speichern</button>
  `;
}

function renderStatsView() {
  return `
    <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:20px;">
      <div style="font-size:20px;font-weight:600;margin-bottom:6px;">Statistik</div>
      <div style="color:${COLORS.muted};">Gespeicherte Serien: ${state.sessions.length}</div>
    </div>
  `;
}

function renderBallisticsView() {
  const ammo = AMMO.find(a => a.name === state.ballisticAmmo) || AMMO[0];
  return `
    <div style="background:${COLORS.card};border:1px solid ${COLORS.cardBorder};border-radius:4px;padding:20px;">
      <div style="font-size:20px;font-weight:600;margin-bottom:6px;">Ballistik</div>
      <div style="color:${COLORS.muted};">${ammo.name} · ${ammo.caliber}</div>
    </div>
  `;
}

async function saveSeries() {
  if (state.shots.length === 0) {
    state.saveError = "Noch keine Treffer erfasst.";
    render();
    return;
  }

  const sum = state.shots.reduce((a,s) => a + shotRing(s), 0);
  state.sessions.push({
    id: uid(),
    date: todayISO(),
    distance: state.distance,
    weapon: state.weapon,
    caliber: state.caliber,
    mode: state.mode,
    discipline: state.discipline,
    range: state.range,
    weather: state.weather,
    shots: state.shots.slice(),
    sum,
    avg: sum / state.shots.length
  });

  state.shots = [];
  persist();
  render();
}

function render() {
  const app = document.getElementById("app");

  app.innerHTML = `
    <div style="margin-bottom:18px;">
      <div class="mono" style="font-size:11px;letter-spacing:2px;color:${COLORS.muted};margin-bottom:2px;">SCHIESSSTAND-PROTOKOLL</div>
      <div style="font-size:30px;font-weight:600;line-height:1.05;">Trefferstatistik</div>
    </div>

    <div class="tabbar" style="display:flex;gap:8px;">
      <div class="btn-tab" data-action="set-view" data-value="new" style="flex:1;text-align:center;padding:10px 0;font-size:15px;font-weight:600;border-radius:2px;background:${state.view==='new'?COLORS.cream:'transparent'};color:${state.view==='new'?COLORS.bg:COLORS.muted};border:1px solid ${state.view==='new'?COLORS.cream:COLORS.cardBorder};">Neue Serie</div>
      <div class="btn-tab" data-action="set-view" data-value="stats" style="flex:1;text-align:center;padding:10px 0;font-size:15px;font-weight:600;border-radius:2px;background:${state.view==='stats'?COLORS.cream:'transparent'};color:${state.view==='stats'?COLORS.bg:COLORS.muted};border:1px solid ${state.view==='stats'?COLORS.cream:COLORS.cardBorder};">Statistik</div>
      <div class="btn-tab" data-action="set-view" data-value="ballistics" style="flex:1;text-align:center;padding:10px 0;font-size:15px;font-weight:600;border-radius:2px;background:${state.view==='ballistics'?COLORS.cream:'transparent'};color:${state.view==='ballistics'?COLORS.bg:COLORS.muted};border:1px solid ${state.view==='ballistics'?COLORS.cream:COLORS.cardBorder};">Ballistik</div>
    </div>

    <div id="view-body">
      ${state.view === "new" ? renderNewView() : state.view === "stats" ? renderStatsView() : renderBallisticsView()}
    </div>
  `;

  attachListeners();
}

function attachListeners() {
  const rangeInput = document.getElementById("range-input");
  if (rangeInput) {
    rangeInput.addEventListener("change", (e) => {
      const val = e.target.value.trim();
      if (val) {
        state.range = val;
        try { localStorage.setItem(RANGE_KEY, val); } catch (err) {}
      }
    });
  }

  document.querySelectorAll("[data-action]").forEach(el => {
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      const action = el.getAttribute("data-action");
      const value = el.getAttribute("data-value");
      if (el.hasAttribute("disabled")) return;

      switch (action) {
        case "set-view":
          state.view = value;
          render();
          break;
        case "set-distance":
          state.distance = Number(value);
          render();
          break;
        case "add-shot":
          addShot(Number(value));
          break;
        case "undo-shot":
          undoShot();
          break;
        case "clear-shots":
          clearShots();
          break;
        case "save-series":
          saveSeries();
          break;
        case "target-tap": {
          const rect = el.getBoundingClientRect();
          const x = ((e.clientX - rect.left) / rect.width) * 100;
          const y = ((e.clientY - rect.top) / rect.height) * 100;
          addShotAtPosition(x, y);
          break;
        }
      }
    });
  });
}

applyTheme();
loadSessions();
render();
fetchWeather(state.range);

if (window.matchMedia) {
  const mq = window.matchMedia("(prefers-color-scheme: dark)");
  const onThemeChange = () => { applyTheme(); render(); };
  if (mq.addEventListener) mq.addEventListener("change", onThemeChange);
  else if (mq.addListener) mq.addListener(onThemeChange);
}
